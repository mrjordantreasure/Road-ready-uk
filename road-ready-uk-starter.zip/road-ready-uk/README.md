# Road Ready UK — learner accounts starter

A responsive React + Vite front end with Supabase authentication and per-user saved learning sessions.

## What is included

- Learner sign-up and sign-in using Supabase Auth
- Email confirmation flow (when enabled in Supabase)
- Automatic learner profile creation
- Per-user learning session storage
- Theory practice sample and saved scores
- Progress snapshot and recent learning history
- Row Level Security policies in `supabase/schema.sql`

## What you need

1. Node.js 20 or later
2. A Supabase account and a new Supabase project
3. A terminal

## Set up the database

1. Open your Supabase project.
2. Go to **SQL Editor**.
3. Paste and run the contents of `supabase/schema.sql`.
4. In **Project Settings → API**, copy the Project URL and publishable/anon key.

## Configure and run

```bash
cp .env.example .env
```

Put your Supabase project values into `.env`:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Then run:

```bash
npm install
npm run dev
```

Open the local address printed by Vite.

## Important security notes

- Never put a Supabase `service_role` key in this app. Only use the publishable/anon key in browser code.
- Keep Row Level Security enabled. The included policies restrict profile and session records to their owner.
- Configure Supabase Auth email confirmation, password rules, redirect URLs and rate limits before launch.
- Add a privacy notice, data retention policy, account deletion workflow and support contact before collecting real users.
- The current profile UI is read-only. Editing profile details, password reset and account deletion are still to be implemented.
- The included theory questions are original sample content, not official DVSA questions. Do not reproduce licensed DVSA content without permission.
- This is a starter implementation, not a security-audited production release.

## Next development steps

- Add profile editing and account deletion
- Add password reset and email change flows
- Add instructor and experienced-driver onboarding
- Expand the original theory content and build mock test sessions
- Add consent, privacy, accessibility and moderation workflows as relevant
- Add automated tests and deploy to a production host
